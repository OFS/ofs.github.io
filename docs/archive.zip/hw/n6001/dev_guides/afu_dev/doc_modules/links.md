[Connecting an AFU to a Platform using PIM]: https://github.com/OPAE/ofs-platform-afu-bbb/blob/master/plat_if_develop/ofs_plat_if/docs/PIM_AFU_interface.md
[PIM Tutorial]: https://github.com/OFS/examples-afu/tree/main/tutorial/afu_types/01_pim_ifc
[Non-PIM AFU Development]: https://github.com/OFS/examples-afu/tree/main/tutorial/afu_types/03_afu_main
[Getting Started Guide: Intel Open FPGA Stack for Intel FPGA PAC N6000]: https://github.com/otcshare/intel-ofs-docs/blob/main/n6000/user_guides/ofs_getting_started/ug_qs_ofs_n6000.md
[Token authentication requirements for Git operations]: https://github.blog/2020-12-15-token-authentication-requirements-for-git-operations/
[4.0 OPAE Software Development Kit]: https://github.com/intel-innersource/applications.fpga.ofs.opensource-documentation/blob/main/docs/hw/n6001/user_guides/ug_qs_ofs_n6001/ug_qs_ofs_n6001.md#40-opae-software-development-kit
[Intel® FPGA Interface Manager Developer Guide: Intel® Open FPGA Stack for Intel® Agilex® FPGAs PCIe Attach]: https://github.com/intel-innersource/applications.fpga.ofs.opensource-documentation/blob/main/docs/hw/n6001/dev_guides/fim_dev/ug_dev_fim_ofs.md
[Signal Tap Logic Analyzer: Introduction & Getting Started]: https://www.intel.com/content/www/us/en/programmable/support/training/course/odsw1164.html
[Quartus Pro Prime Download]: https://www.intel.com/content/www/us/en/software-kit/727906/intel-quartus-prime-pro-edition-design-software-version-23-1-for-linux.html
