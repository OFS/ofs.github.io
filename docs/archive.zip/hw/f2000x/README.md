Location for SoC Attach Collateral for OFS.
